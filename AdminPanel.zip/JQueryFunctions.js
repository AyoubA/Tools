//DATATABLE SCROLL -->
$(document).ready(function() {
    $("#tabs").tabs( {
        "activate": function(event, ui) {
            $( $.fn.dataTable.tables( true ) ).DataTable().columns.adjust();
        }
    } );
     
     var table = $("#DBTable").dataTable( {
        "scrollY": "200px",
        "scrollCollapse": true,
        "paging": false,
        "jQueryUI": true
    });
	
$('#DBTable tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
        }
    } );
 
    $('#button').click( function () {
        table.row('.selected').remove().draw( false );
    } );
        
	
} );

  //JQUERY BUTTON DIALOG 
  $(function() {
    var name = $( "#name" ),
      description = $( "#description" ),
      category = $( "#category" ),
	  price = $( "#price" ),
	  specification = $( "#specification" ), 
	  pictures = $( "#pictures" ),
      allFields = $( [] ).add( name ).add( description ).add( category ).add(price).add(specifcation).add(pictures),
      tips = $( ".validateTips" );
 
    function updateTips( t ) {
      tips
        .text( t )
        .addClass( "ui-state-highlight" );
      setTimeout(function() {
        tips.removeClass( "ui-state-highlight", 1500 );
      }, 500 );
    }
 
    function checkLength( o, n, min, max ) {
      if ( o.val().length > max || o.val().length < min ) {
        o.addClass( "ui-state-error" );
        updateTips( "Length of " + n + " must be between " +
          min + " and " + max + "." );
        return false;
      } else {
        return true;
      }
    }
 
    $( "#dialog-form" ).dialog({
      autoOpen: false,
      height: 300,
      width: 350,
      modal: true,
      buttons: {
        "Add a new product": function() {
          var bValid = true;
          allFields.removeClass( "ui-state-error" );
 
          bValid = bValid && checkLength( name, "username", 3, 16 );
          bValid = bValid && checkLength( description, "email", 6, 256 );
          bValid = bValid && checkLength( category, "password", 5, 16 );
		  bValid = bValid && checkLength( price, "password", 5, 16 );
		  bValid = bValid && checkLength( specifcation, "password", 5, 16 );
		  
 
          if ( bValid ) {
            //SQL CODE
          }
        },
        Cancel: function() {
          $( this ).dialog( "close" );
        }
      },
      close: function() {
        allFields.val( "" ).removeClass( "ui-state-error" );
      }
    });
 
    $( "#new-product" )
      .button()
      .click(function() {
        $( "#dialog-form" ).dialog( "open" );
      });
  });