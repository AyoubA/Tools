<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
<head>
	<title>Admin Control Panel</title>
	<!-- IMPORT JQUERY UI -->
  <meta charset="utf-8">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
  <link rel="stylesheet" href="//cdn.datatables.net/plug-ins/be7019ee387/integration/jqueryui/dataTables.jqueryui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
  <script src="//cdn.datatables.net/1.10.0/js/jquery.dataTables.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">

  <!-- IMPORT OF JQUERY FUNCTIONS -->
  <script type="text/javascript" src="JQueryFunctions.js"></script>

  
  <style type="text/css"> 
  .selected {
  background-color: red;
  font-size:large;
  !important
}
  </style>
  
</head>
<body>
<?php include("DatabasePosts.php") ?>

<h1> ADMIN CONTROL PANEL </h1>

<div id="tabs" >
  <ul>
    <li><a href="#tabs-Products">Products</a></li>
    <li><a href="#tabs-Customer">Customer</a></li>
    <li><a href="#tabs-Order">Orders</a></li>
  </ul>
  <div id="tabs-Products">
  <!-- PRODUCT TAB CONTENT-->
  <table id="DBTable" class="display" style="table-layout: fixed; width: 90%">
		<thead>
		<tr class="ui-widget-header ">
			<th width="50px">ID</th>
			<th>Name</th>
			<th>Description</th>
			<th>Category(ID)</th>
			<th>Price</th>
			<th>Specification</th>
			<th>Pictures</th>
			</tr>
			</thead>
			
			<!-- PHP CODE TO READ DATABASE -->
			<tbody>
	<tr>
	<td>0</td>
	<td>Drill</td>
	<td>It spins</td>
	<td>Drills (1)</td>
	<td>£50.00</td>
	<td>30mmx60mm</td>
	<td>...</td>
	</tr>
	<tr>
	<td>1</td>
	<td>Saw</td>
	<td>It spins really fast, like you could cut yo self on thi...</td>
	<td>Saws (4)</td>
	<td>£30.00</td>
	<td>700mmx340mm</td>
	<td>...</td>
	</tr>
		<tr>
	<td>2</td>
	<td>Screwdriver</td>
	<td>It turns things</td>
	<td>Hand Tools (7)</td>
	<td>£5.00</td>
	<td>400mmx20mm</td>
	<td>...</td>
	</tr>
			<tr>
	<td>3</td>
	<td>Hand Saw</td>
	<td>It cuts things</td>
	<td>Hand Tools (7)</td>
	<td>£5.00</td>
	<td>400mmx50mm</td>
	<td>...</td>
	</tr>
			<tr>
	<td>4</td>
	<td>Jigsaw</td>
	<td>It cuts things fast</td>
	<td>Saws (4)</td>
	<td>£25.00</td>
	<td>90mmx70mm</td>
	<td>...</td>
	</tr>
	
</tbody>	
 </table>
 
 <br/>
 
 <p> SELECTED: </p>
 <div id="result" class="selected" > <script>
$("table").selectable({
  filter: "tr",
  stop: function() {
        var str = "NOTHING SELECTED";
        $( ".ui-selected", this ).each(function() {
           
          str = str +  $( this ).html() + " | " ;
          
        });
    $('#result').html(str);

  }
});
</script>
</div>
 
 <button id="new-product">Add New Product</button>
  <button id="create-user">Delete Product</button>
   <button id="create-user">Edit Product</button>

   <div id="dialog-form" title="Add a new product">
  <p class="validateTips">All form fields are required.</p>
  <form>
  <fieldset>
    <label for="name">Name</label>
    <input type="text" name="name" id="name" class="text ui-widget-content ui-corner-all">
    <label for="email">Description</label>
    <input type="text" name="description" id="description" value="" class="text ui-widget-content ui-corner-all">
    <label for="password">Category</label>
    <input type="text" name="category" id="category" value="" class="text ui-widget-content ui-corner-all">
	    <label for="password">Price</label>
    <input type="text" name="price" id="price" value="" class="text ui-widget-content ui-corner-all">
	    <label for="password">Specifcation</label>
    <input type="text" name="Specifcation" id="Specifcation" value="" class="text ui-widget-content ui-corner-all">
		    <label for="password">Picture Links</label>
    <input type="text" name="Pictures" id="Pictures" value="" class="text ui-widget-content ui-corner-all">
	
  </fieldset>
  </form>
</div>
 
 
  </div>
 <!----------PRODUCT TAB END--------------->
  <div id="tabs-Customer">
    <!-- CUSTOMER TAB CONTENT-->
  </div>
 <!----------CUSTOMER TAB END--------------->
  <div id="tabs-Order">
    <!-- ORDERS TAB CONTENT-->
  </div>
</div>
<!----------ORDERS TAB END--------------->


</body>
</html>


