<?php

$connection = mysql_connect("localhost", "root", "") or
 die ("Unable to connect to the database server.");
$database = "mysql";
mysql_select_db($database, $connection) or die ("Unable to connect to the database.");
 ///////////////////////////////
/* Product related functions */
function GetProductID($inID=null) {
}

function GetProductsCat($inID=null,$inCat=null){
}

function GetPopularProducts(){
}

function SearchProducts($inString=null){
}

function ProductSold($inID){
}

function AddProduct(){
}

function DeleteProduct($inID=null){
}

function EditProduct($inID=null){
}

 ////////////////////////////////
/* Customer related functions */

function NewCustomer(){
}

function DeleteCustomer($inID=null){
}

function SearchCustomer($inString=null){
}

function GetCustomer(){
}

?>





















